sub init()
    m.top.message = "Hello from MyComponentLib:Bar"
    print "[Bar::init]"
end sub
