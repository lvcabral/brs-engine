sub init()
    m.top.message = "Hello from MyLib:Bar"
    print "[MyLib:Bar::init]"
end sub

function getMessage() as string
    return m.top.message
end function
